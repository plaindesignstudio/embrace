import Glide from "@glidejs/glide";
import LazyLoad from "vanilla-lazyload";

// slides
const clientLogosGlide = document.querySelector(".client-logos-glide");
if (clientLogosGlide) {
  new Glide(".client-logos-glide", {
    type: "carousel",
    perView: 6,
    animationTimingFunc: "linear",
    gap: 60,
    autoplay: 2000,
    breakpoints: {
      1500: {
        perView: 5,
      },
      992: {
        gap: 40,
        perView: 4,
      },
      550: {
        gap: 20,
        perView: 3,
      },
    },
  }).mount();
}

const testimonialsGlide = document.querySelector(".testimonials-glide");
if (testimonialsGlide) {
  new Glide(".testimonials-glide", {
    type: "carousel",
    gap: 20,
    autoplay: 3000,
  }).mount();
}

const caseStudyThumbnails = document.querySelectorAll(
  ".glide__slide--thumbnail"
);
const caseStudyBackground = document.querySelectorAll(".work-background");
const caseStudyContent = document.querySelectorAll(".slidein-content");
const caseStudiesGlide = document.querySelector(".case-studies-glide");
const slides = document.querySelector(".glide__slides--case-studies");
if (caseStudiesGlide) {
  const caseStudyGlide = new Glide(".case-studies-glide", {
    type: "carousel",
    gap: 30,
    perView: 6,
    bound: true,
    breakpoints: {
      1900: {
        perView: 5,
        gap: 20,
      },
      1400: {
        perView: 4,
      },
      1024: {
        perView: 3,
      },
      768: {
        gap: 10,
        perView: 2,
      },
    },
  });

  slides.addEventListener("click", function (e) {
    const slide = e.target.closest("li");
    if (slide) {
      caseStudyGlide.go(`=${slide.dataset.case}`);
    }
  });

  caseStudyGlide.on("run.after", () => {
    caseStudyThumbnails.forEach((currentCase) => {
      if (currentCase.classList.contains("glide__slide--active")) {
        let caseId = currentCase.dataset.case;
        // Change the background
        caseStudyBackground.forEach((current) => {
          if (current.dataset.case === caseId) {
            current.classList.add("work-background--active");
          } else {
            current.classList.remove("work-background--active");
          }
        });

        // Change the content
        caseStudyContent.forEach((current) => {
          if (current.dataset.case === caseId) {
            current.classList.add("slidein-content--active");
          } else {
            current.classList.remove("slidein-content--active");
          }
        });
      }
    });
  });

  caseStudyGlide.mount();
}

// lazyloading images
const lazyBg = new LazyLoad({
  elements_selector: ".case-study-lazy",
  thresholds: "-50%",
  cancel_on_exit: false,
});

const lazyImg = new LazyLoad({
  elements_selector: ".lazy-img",
  cancel_on_exit: false,
});

//count up
function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,");
}

const animationDuration = 1500;
// Calculate how long each ‘frame’ should last if we want to update the animation 60 times per second
const frameDuration = 1000 / 60;
const totalFrames = Math.round(animationDuration / frameDuration);
const easeOutQuad = (t) => t * (2 - t);

const animateCountUp = (el) => {
  let frame = 0;

  const countTo = parseInt(el.innerHTML, 10);

  const counter = setInterval(() => {
    frame++;

    const progress = easeOutQuad(frame / totalFrames);
    const currentCount = Math.round(countTo * progress);

    if (parseInt(el.innerHTML, 10) !== currentCount) {
      el.innerHTML = formatNumber(currentCount);
    }

    if (frame === totalFrames) {
      clearInterval(counter);
    }
  }, frameDuration);
};

const runAnimations = () => {
  const countupEls = document.querySelectorAll(".countup");
  countupEls.forEach(animateCountUp);
};

// fire the countup animation when they are in viewport
const stats = document.querySelectorAll(".stats");
if (window.IntersectionObserver && stats.length) {
  const options = {
    // root: null the documentum element that is used as a viewport for checking visibility of the target DEFAULT IS WINDOW
    thresholds: 0.2, // can be a single number or an array of numbers from 0 - 1, it indicates at what percentage of the target's visibility the observer callback should be executed
    rootMargin: "0px 0px -150px 0px", // margin around the root
  };

  const observer = new IntersectionObserver(function (entries, observer) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        runAnimations();
        observer.unobserve(entry.target);
      }
    });
  }, options);
  stats.forEach((stat) => observer.observe(stat));
} else {
  runAnimations();
}
