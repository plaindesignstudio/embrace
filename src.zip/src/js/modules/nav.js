
const menuOpenButton = document.querySelector(".openmenu");
const menuCloseButton = document.querySelector(".menu-close-button");
const mobileMenuDropdown = document.querySelector(".mobile-menu-dropdown");

menuOpenButton.addEventListener("click", () => {
  document.body.classList.add("deactivatescroll");
  mobileMenuDropdown.classList.add("mobile-menu-dropdown--open");
});

menuCloseButton.addEventListener("click", () => {
  document.body.classList.remove("deactivatescroll");
  mobileMenuDropdown.classList.remove("mobile-menu-dropdown--open");
});
