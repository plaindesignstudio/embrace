// import $ from "jquery";
// window.jQuery = $;
// window.$ = $;
// global.jQuery = $;
const scroll = require("./modules/scroll.js");
const slider = require("./modules/slider.js");
