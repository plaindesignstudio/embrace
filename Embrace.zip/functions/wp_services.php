<?php 

// function that runs when shortcode is called
function wpb_demo_shortcode($service) { 


  ob_start();
  $service_list = $service['service_id'];
  return get_template_part('includes/service', 'list', $service_list );
    
  // Output needs to be return
  //return $service_list;
  }

  // function that runs when shortcode is called
function wpb_articles_carousel_shortcode() { 

  ob_start();
  
  $carousel =  get_template_part('includes/articles', 'carousel' );
    
  $carousel  = ob_get_clean(); // store buffered output content.

  return $carousel; // Return the content.
  // Output needs to be return
  //return $service_list;
  }

  // register shortcode
  add_shortcode('greeting', 'wpb_demo_shortcode');
  add_shortcode('articles_carousel', 'wpb_articles_carousel_shortcode');