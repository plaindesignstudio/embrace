<?php
/**
* A Simple Category Template
*/

get_header(); ?>
  <div class="z-index-100" id="postTrigger">

     <div class="full-height-div bg-gradient-primary position-relative" style="min-height: 40vh; overflow: hidden;">
      <div class="table-container" style="min-height: 40vh; overflow: hidden;">
          <div class="centre-content">
       <div class='container-fluid'>
         <div class='row'>
           <div class='col-md-12 col-xl-12 col-lg-12 col-12 p-0 mx-auto z-index-100'>
                 <div class="container">
                     <div class="col-12" style="height: 100px"></div>
                     <div class='col-12'>
            <?php echo get_the_archive_title() ?>
                        </div>
                       <?php if ( category_description() ) : ?>
<div class="archive-meta col-md-12 col-lg-8"><?php echo category_description(); ?></div>
<?php endif; ?>
               </div>
               </div>


             <div class='col-md-4  col-lg-4 col-12 p-0 mx-auto z-index-100'>
             </div>
        </div>
          </div>
        </div>
         </div>
     </div>
  </div>

       <?php

    global $post;

    $children = get_pages( array( 'child_of' => $post->ID ) );

?>

<div class="full-height z-index-100" style="min-height: 50vh;" id="postTrigger">
    <div class="wp-spacer-sm"></div>
<div class="container">
    <div class="row">
        <div class='col-md-8 col-lg-8 col-xl-8 col-12 p-0'>
             <?php// get_template_part('includes/section', 'content') ?>
             <?php function custom_posts_per_page( $query ) {

    if ( $query->is_archive('cpt_name') || $query->is_category() ) {
        set_query_var('posts_per_page', 1);
    }
}
add_action( 'pre_get_posts', 'custom_posts_per_page' ); ?>
    </div>
 <div id="sidebarTrigger" class='col-md-4 reveal-up col-lg-4 col-xl-4 mx-auto col-12 z-index-100 position-relative'>
     <div class="wp-spacer-sm"></div>
       <div class="table-container p-0" style="min-height: 0vh">

    <div class="w-100 h-100 p-0 position-relative" style="opacity: 1;">

            <?php get_template_part('includes/contact', 'sidebar') ?>

             <div class='z-index-100 p-2 rounded mb-4 shadow position-relative'>
               <h3>Category</h3>
      <?php
				get_template_part( 'template-parts/article/article', 'widgets' );
?>
        <img class="scrollSpeed position-absolute" data-trigger="sidebarTrigger" data-from='{"yPercent": "-0", "rotate": "-20"}' data-to='{"yPercent": "20", "rotate": "20"}'  style="top: -50%; min-width: 100px; width: 20%; right: -20%;" src="<?php bloginfo('template_directory'); ?>/assets/images/banner/triangle.svg">
       </div>

       </div>

    </div>
        </div>
    </div>
</div>
    <div class="wp-spacer-md"></div>
    </div>


<?php get_footer(); ?>
