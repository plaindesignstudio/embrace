<?php get_header(); ?>
  
    <div id="titleTrigger"></div>    

<?php get_template_part('includes/banner', 'content') ?>


<div class="full-height z-index-100" style="min-height: 50vh;" id="postTrigger">
<div class="wp-spacer-md"></div>
<div class="container">
    <div class="row">
        <div class='col-12'>
        


<?php if (have_posts()) : while (have_posts()) :the_post(); ?>

    <?php the_content(); ?> 

<?php endwhile; endif; ?>
    </div>
</div>
    </div>
    <div class="wp-spacer-lg"></div>
</div>



<?php get_footer(); ?>

