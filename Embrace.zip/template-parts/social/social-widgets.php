<?php
/**
 * Displays footer widgets if assigned
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

?>

		<?php if ( is_active_sidebar( 'sidebar-5' ) ) {
			?>
			<div class="widget-column footer-widget-3 text-center col-md-4 col-sm-12 mb-4">
				<h1>ouewnh;qowfuehi</h1>
			</div>
		<?php } ?>
