<?php if ( has_post_thumbnail() ){
$url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>




 <div id="titlebannerTrigger" class="full-height-div position-relative bg-light" style="min-height: 75vh; overflow: hidden;">
    <div class="table-container" style="min-height: 75vh">
      <img class="scrollSpeed position-absolute" data-trigger="titlebannerTrigger" data-from='{"yPercent": "100"}' data-to='{"yPercent": "40", "rotate": "40"}'  style="bottom: 10%; right: 10%; min-width: 100px;" width="20%"  src="<?php bloginfo('template_directory'); ?>/assets/images/banner/triangle.svg">

      <div class="w-100 h-100 top-0 div-overlay-bg scrollSpeed z-index-100 position-absolute" style="opacity: 1"
       data-trigger="titlebannerTrigger" data-from='{"yPercent": "-90"}' data-to='{"yPercent": "50"}'>
            <div class="bg-light fade-in position-absolute m-0 blurimage" style="background:
<?php  echo 'url('. $url.');' ?> background-repeat: no-repeat; background-size: cover; height: 100%; width: 100%; overflow: hidden; opacity: 0.1; filer: brightness(1) blur(0px); background-positon: center; object-fit: cover;">
</div>
        </div>

       <div class=" d-none w-100 h-100 position-absolute opacity-primary bottom-0 z-index-100"></div>

        <div class="centre-content">
                  <div class="container">
               <div class="z-index-100">
                          <div class="row">
                   <div class="wp-spacer-sm"></div>

                   <div class='col-12 mx-auto'>
                       <div>
                 <div class="scrollSpeed z-index-100 position-absolute" data-trigger="titlebannerTrigger" data-from='{"yPercent": "-500"}' data-to='{"yPercent": "300"}'>
                    <h1 class="mr-1 ml-1 font-weight-bold text-dark" style="z-index: 100"><?php the_title(); ?></h1>
                </div>

                   </div>
                              </div>

                    <div class='d-none col-md-4 reveal-up col-lg-4 col-12 p-0 z-index-100'>
                   </div>
                   </div>
                   <img class="scrollSpeed position-absolute" data-trigger="powetopTrigger" data-from='{"yPercent": "100"}' data-to='{"yPercent": "20", "rotate": "20"}'  style="top: -50%; min-width: 300px; width: 20%; left: -20%;" src="<?php bloginfo('template_directory'); ?>/assets/images/banner/semi-circle.svg">
            </div>
        </div>
               </div>
        </div>
     </div>


<?php } else { ?>

  <div id="logoTrigger position-absolute top-0"></div>

   <div class="full-height-div" style="min-height: 50vh">


      <div class="table-container"   style="min-height: 50vh">
          <div class="centre-content">
                      <div class="wp-spacer-xl" id="iconswrapper"> </div>
                 <div data-trigger="logoTrigger" data-scroll-speed="+100">

                <div  class="container z-index-100">
                   <div  class="row">

                     <div class="col-xl-8 mx-auto text-center col-lg-10 col-md-12 col-12 z-index-100">

                              <h1 class="display-3 font-weight-bold"><?php the_title(); ?></h1>


                                    </div>

               </div>
          </div>

      </div>

       <div class="wp-spacer-sm" ></div>



  </div>
      </div>
  </div>

<?php }?>
