<div class="w-100 z-index-100">
<div class="row">
  <div class="col-12">
  <div class="table-container" style="min-height: 10vh">
      <div class="centre-content position-relative" id="contactSection">
        <div class="radius-lg bg-primary text-light z-index-100 mx-auto z-index-100">
          <img class="scrollSpeed position-absolute top-0 z-index-100" data-trigger="contactSection" data-from='{"yPercent": "0"}' data-to='{"yPercent": "50", "rotate": "-20"}' style="top: 0%; left: 0; max-width: 100px; min-width: 50px;" width="20%"  src="<?php bloginfo('template_directory'); ?>/assets/images/banner/contact.svg">

                <h3 class="p-2 text-light text-center m-0 z-index-100">Contact Us</h3>
                <p class="p-1 text-light text-center m-0 z-index-100">
We work with adults with a wide range of conditions. We specialise in communication assessment and therapy.
                </p>
<p class="p-1 text-light text-center m-0 z-index-100">
  <a class="mobile-center" href="<?php echo site_url(); ?>/contact/">
    <button class="btn-light mx-auto">Get In Touch</button>
  </a>
</p>
                <div class="m-0 position-absolute w-100 h-100 overflow-hidden radius-lg" style="background:
                url('<?php bloginfo('template_directory'); ?>/assets/images/banner/background-plain-blue.svg'); background-repeat: no-repeat;
                background-size: cover; height: 100%; width: auto; opacity: 1; filter: brightness(1) blur(0px) saturate(1); top: 0px; background-position: center;">
                </div>
    </div>
        </div>
</div>

       </div>
      <div class="wp-spacer-sm"></div>
    </div>
    </div>
